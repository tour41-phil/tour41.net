<?php

namespace WCML\StandAlone;

interface IStandAloneAction {}
