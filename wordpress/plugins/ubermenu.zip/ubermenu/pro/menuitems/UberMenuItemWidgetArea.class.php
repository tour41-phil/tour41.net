<?php

class UberMenuItemWidgetArea extends UberMenuItemDefault{

	var $type = 'widget_area';

	function get_anchor( $atts ){ return ''; }

}
