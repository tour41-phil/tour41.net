<?php

namespace WPML\WPSEO\Shared\Upgrade\Commands;

interface Command {
	public static function run();
}
