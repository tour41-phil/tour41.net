<?php
/**
 * Common events helper functions
 *
**/
