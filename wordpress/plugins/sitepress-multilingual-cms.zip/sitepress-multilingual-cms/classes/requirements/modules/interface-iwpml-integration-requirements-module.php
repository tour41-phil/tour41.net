<?php

interface IWPML_Integration_Requirements_Module {

	public function get_requirements();
}
