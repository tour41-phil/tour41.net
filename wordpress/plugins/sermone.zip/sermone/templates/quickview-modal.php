<?php 
/**
 * Quickview modal
 * 
 * @since 1.0.0 
 * @version 1.0.0
 */

?>
<div id="sermone-modal" class="sermone-modal-container">
  <div class="sermone-modal-content">
    <!-- Content ajax load -->
  </div>
</div> <!-- #sermone-modal -->