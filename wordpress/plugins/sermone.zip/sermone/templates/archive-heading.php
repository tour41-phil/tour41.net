<?php 
/**
 * Archive heading template 
 * 
 * @since 1.0.0
 * @version 1.0.0
 */

?>
<h2 class="sermone-heading-page"><?php echo __( 'Sermons Archive', 'sermone' ) ?></h2>