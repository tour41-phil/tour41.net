=== Alone ===
Compatible with WordPress 6.4.x.
Alone always keeps bundled plugins up-to-date to improve your website with new features.

ALONE – Powerful and flexible WordPress theme that comes with 30+ unique and stunning demos, suitable for all your idea and different types of Non-profit Organizations, Ngo, Church, Events, Political, Candidate, Campaign project…

For more information about Alone please go to http://docs.beplusthemes.com/Alone7/.

== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Type in Alone in the search form and press the 'Enter' key on your keyboard.
3. Click on the 'Activate' button to use your new theme right away.
4. Go to http://docs.beplusthemes.com/Alone7/ for a guide on how to customize this theme.
5. Navigate to Appearance > Customize in your admin panel and customize to taste.

== Copyright ==

Alone WordPress Theme, Copyright 2016 - 2026 by Beplusthemes
