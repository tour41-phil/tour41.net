<?php
/**
 * Import pack data package demo
 *
 * @package Import Pack
 * @author Beplusthemes
 */
$plugin_includes = array(
  array(
    'name'     => __('Elementor Website Builder', 'alone'),
    'slug'     => 'elementor',
  ),
  array(
    'name'     => __('Alone Addons', 'alone'),
    'slug'     => 'alone-addons',
    'source'   => IMPORT_REMOTE_SERVER_PLUGIN_DOWNLOAD . 'alone-addons.zip',
  ),
  array(
    'name'     => __('UberMenu 3 - The Ultimate WordPress Mega Menu', 'alone'),
    'slug'     => 'ubermenu',
    'source'   => IMPORT_REMOTE_SERVER_PLUGIN_DOWNLOAD . 'ubermenu.zip',
  ),
  array(
    'name'     => __('Kirki Customizer Framework', 'alone'),
    'slug'     => 'kirki',
  ),
  array(
    'name'     => __('Advanced Custom Fields PRO', 'alone'),
    'slug'     => 'advanced-custom-fields-pro',
    'source'   => IMPORT_REMOTE_SERVER_PLUGIN_DOWNLOAD . 'advanced-custom-fields-pro.zip',
  ),
  array(
    'name'     => __('GiveWP - Donation Plugin and Fundraising Platform', 'alone'),
    'slug'     => 'give',
  ),
  array(
    'name'     => __('The Events Calendar', 'alone'),
    'slug'     => 'the-events-calendar',
  ),
  array(
    'name'     => __('Sermon\'e - Sermons Management', 'alone'),
    'slug'     => 'sermone',
    'source'   => IMPORT_REMOTE_SERVER_PLUGIN_DOWNLOAD . 'sermone.zip',
  ),
  array(
    'name'     => __('Yoast SEO', 'alone'),
    'slug'     => 'wordpress-seo',
  ),
  array(
    'name'     => __('WooCommerce', 'alone'),
    'slug'     => 'woocommerce',
  ),

);


$plugin_includes_multiplelanguages = array(
  array(
    'name'     => __('Elementor Website Builder', 'alone'),
    'slug'     => 'elementor',
  ),
  array(
    'name'     => __('Elementor Pro', 'alone'),
    'slug'     => 'elementor-pro',
    'source'   => IMPORT_REMOTE_SERVER_PLUGIN_DOWNLOAD . 'elementor-pro.zip',
  ),
  array(
    'name'     => __('Alone Addons', 'alone'),
    'slug'     => 'alone-addons',
    'source'   => IMPORT_REMOTE_SERVER_PLUGIN_DOWNLOAD . 'alone-addons.zip',
  ),
  array(
    'name'     => __('Kirki Customizer Framework', 'alone'),
    'slug'     => 'kirki',
  ),
  array(
    'name'     => __('Advanced Custom Fields PRO', 'alone'),
    'slug'     => 'advanced-custom-fields-pro',
    'source'   => IMPORT_REMOTE_SERVER_PLUGIN_DOWNLOAD . 'advanced-custom-fields-pro.zip',
  ),
  array(
    'name'     => __('GiveWP - Donation Plugin and Fundraising Platform', 'alone'),
    'slug'     => 'give',
  ),
  array(
    'name'     => __('The Events Calendar', 'alone'),
    'slug'     => 'the-events-calendar',
  ),
  array(
    'name'     => __('Yoast SEO', 'alone'),
    'slug'     => 'wordpress-seo',
  ),
  array(
    'name'     => __('AccessYes Accessibility Widget for ADA, EAA & WCAG Readiness', 'alone'),
    'slug'     => 'accessibility-widget',
  ),
  array(
    'name'     => __('WooCommerce', 'alone'),
    'slug'     => 'woocommerce',
  ),
  array(
    'name'     => __('WPML Multilingual CMS', 'alone'),
    'slug'     => 'sitepress-multilingual-cms',
    'source'   => IMPORT_REMOTE_SERVER_PLUGIN_DOWNLOAD . 'sitepress-multilingual-cms.zip',
  ),
  array(
    'name'     => __('WPML String Translation', 'alone'),
    'slug'     => 'wpml-string-translation',
    'source'   => IMPORT_REMOTE_SERVER_PLUGIN_DOWNLOAD . 'wpml-string-translation.zip',
  ),
  array(
    'name'     => __('WPML SEO', 'alone'),
    'slug'     => 'wp-seo-multilingual',
    'source'   => IMPORT_REMOTE_SERVER_PLUGIN_DOWNLOAD . 'wp-seo-multilingual.zip',
  ),
  array(
    'name'     => __('Advanced Custom Fields Multilingual', 'alone'),
    'slug'     => 'acfml',
    'source'   => IMPORT_REMOTE_SERVER_PLUGIN_DOWNLOAD . 'acfml.zip',
  ),
  array(
    'name'     => __('WooCommerce Multilingual & Multicurrency', 'alone'),
    'slug'     => 'woocommerce-multilingual',
    'source'   => IMPORT_REMOTE_SERVER_PLUGIN_DOWNLOAD . 'woocommerce-multilingual.zip',
  ),

);

return apply_filters( 'beplus/import_pack/package_demo', [
    [
        'package_name' => 'alone-main',
        'preview' => get_template_directory_uri() . '/install/import-pack/images/alone-main-preview.png', // image size 680x475
        'url_demo' => 'https://alonethemes.com/',
        'title'        => __( 'Alone Main – 40+ Ready-to-Import Homepages', 'alone' ),
        'description'  => __( 'The primary Alone demo featuring 40+ professionally designed homepage layouts and a complete set of inner pages, including About, Contact, Company, Blog, and more.', 'alone' ),
        'plugins' => $plugin_includes,
    ],
    [
      'package_name' => 'alone-rtl',
      'preview' => get_template_directory_uri() . '/install/import-pack/images/alone-rtl-preview.png', // image size 680x475
      'url_demo' => 'https://rtl.alonethemes.com/',
      'title'        => __( 'Alone RTL – Right-to-Left Demo', 'alone' ),
      'description'  => __( 'A fully optimized RTL version of the Alone theme, including homepage demos and a complete collection of inner pages such as About, Contact, Company, Blog, and more.', 'alone' ),
      'plugins' => $plugin_includes_multiplelanguages,
    ],
] );
