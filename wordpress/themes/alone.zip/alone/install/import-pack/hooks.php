<?php
/**
 * Import pack hooks
 *
 * @package Import Pack
 */

add_action( 'admin_init', 'alone_import_pack_defineds' );
add_action( 'admin_menu', 'alone_register_import_menu' );
